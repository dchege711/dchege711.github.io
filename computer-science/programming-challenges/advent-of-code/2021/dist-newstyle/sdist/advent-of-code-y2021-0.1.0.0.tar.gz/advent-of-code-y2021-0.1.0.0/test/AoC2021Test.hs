module Main (main) where

import Paths_advent_of_code_y2021 (getDataFileName)

import Data.String (IsString(fromString))
import System.IO (withFile, IOMode (ReadMode), hGetContents)

import SonarSweep.SonarSweep as SonarSweep
    ( numIncreases, num3MeasurementIncreases )

main :: IO ()
main = do
    fp <- getDataFileName "src/SonarSweep/scratchpad/sample.txt"
    putStr "Testing Day 01. Sonar Sweep... "
    withFile
        fp
        ReadMode
        (\h -> do
            s <- hGetContents h
            assert
                (SonarSweep.numIncreases (lines (fromString s)) == 7)
                (putStr "PASSED")

            assert
                (SonarSweep.num3MeasurementIncreases (lines (fromString s)) == 10)
                (putStr "PASSED")

            assert
                False
                (putStr "PASSED")

        )
