module Main where

import qualified AoC2021 (solution01)

main :: IO ()
main = do
  AoC2021.solution01
