module Main where

import qualified AoC2021 (allSolutions)

main :: IO ()
main = do
  AoC2021.allSolutions
